//
//  CellWithTwoLabelsAndImageViewModel.swift
//  m14full
//
//  Created by Александра Угольнова on 27.11.2022.
//

import UIKit


struct CellWithTwoLabelsAndImageViewModel {
    let text: String
    let image: UIImage
}
